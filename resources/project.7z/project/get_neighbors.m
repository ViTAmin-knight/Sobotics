function neighbors = get_neighbors(pos, maze_grid, wall_map, elevator_map)
    % 获取上下左右合法邻居（考虑墙体） + 电梯邻居
    dirs = [-1 0; 1 0; 0 -1; 0 1];
    dir_names = {'up','down','left','right'};
    neighbors = [];

    for i = 1:4
        d = dirs(i,:);
        np = pos + d;
        if np(1) < 1 || np(2) < 1 || ...
           np(1) > size(maze_grid,1) || np(2) > size(maze_grid,2)
            continue;
        end
        if any(strcmp(maze_grid{np(1), np(2)}, 'void'))
            continue;
        end
        % 墙体检查
        if is_blocked_by_wall(pos, np, wall_map, dir_names{i})
            continue;
        end
        neighbors(end+1,:) = np;
    end

    % 电梯邻居（同组传送）
    for eid = keys(elevator_map)
        coords = elevator_map(eid{1});
        idx = find(all(coords == pos, 2));
        if ~isempty(idx)
            for j = 1:size(coords,1)
                if ~isequal(coords(j,:), pos)
                    neighbors(end+1,:) = coords(j,:);
                end
            end
        end
    end
end