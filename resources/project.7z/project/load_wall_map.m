function wall_map = load_wall_map()
    max_attempts = 5;
    retry_delay = 0.1;

    for attempt = 1:max_attempts
        try
            str = fileread('wall_map.json');
            if isempty(str)
                error("wall_map.json 是空的。");
            end
            data = jsondecode(str);
            break;
        catch e
            fprintf("⚠️ 第 %d 次尝试读取 wall_map.json 失败：%s\n", attempt, e.message);
            if attempt == max_attempts
                error("❌ 多次尝试读取 wall_map.json 失败，终止加载。");
            end
            pause(retry_delay);
        end
    end

    % ✅ 构建 direction-aware key map
    wall_map = containers.Map();

    for i = 1:length(data)
        row = data(i).row + 1;  % 假设你的 row/col 是从 0 起始的
        col = data(i).col + 1;
        directions = data(i).walls;

        for j = 1:length(directions)
            key = sprintf('%d_%d_%s', row, col, directions{j});
            wall_map(key) = true;
        end
    end

    % 可选调试输出
    keys_list = keys(wall_map);
    for i = 1:length(keys_list)
        fprintf("🚧 %s\n", keys_list{i});
    end
end
