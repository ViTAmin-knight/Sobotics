function reachable = bfs_reachable(start_pos, maze_grid, wall_map, elevator_map)
    [~, row_offset, col_offset] = load_maze_grid();

    visited = containers.Map();
    key = @(pos) sprintf("%d_%d", pos(1), pos(2));
    visited(key(start_pos)) = true;

    queue = {start_pos};
    reachable = start_pos;

    while ~isempty(queue)
        current = queue{1}; queue(1) = [];

        neighbors = get_neighbors(current, maze_grid, wall_map, elevator_map);
        for i = 1:size(neighbors,1)
            n = neighbors(i,:);
            k = key(n);
            if ~isKey(visited, k)
                visited(k) = true;
                queue{end+1} = n;
                reachable(end+1,:) = n;
            end
        end
    end
end
