function [item_targets, exit_targets] = find_goal_tiles(maze_grid)
    item_targets = containers.Map();
    exit_targets = containers.Map();

    for r = 1:size(maze_grid,1)
        for c = 1:size(maze_grid,2)
            types = maze_grid{r,c};
            for t = types
                txt = t{1};
                if startsWith(txt, 'item:')
                    key = strtrim(lower(extractAfter(txt, 'item:')));
                    item_targets(key) = [r, c];
                elseif startsWith(txt, 'exit:')
                    key = strtrim(lower(extractAfter(txt, 'exit:')));
                    exit_targets(key) = [r, c];
                end
            end
        end
    end
end
