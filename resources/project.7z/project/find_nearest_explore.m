function target = find_nearest_explore(pos, maze_grid)
    wall_map = load_wall_map();
    elevator_map = load_elevator_map();
    [~, row_offset, col_offset] = load_maze_grid();

    % 获取当前 agent 所在区域的所有可达位置（BFS）
    reachable = bfs_reachable(pos, maze_grid, wall_map, elevator_map);

    % 找出这些位置中是 explore 的格子
    explore_cells = [];
    for i = 1:size(reachable, 1)
        r = reachable(i,1);
        c = reachable(i,2);
        maze_r = r - row_offset;
        maze_c = c - col_offset;

        if maze_r < 1 || maze_c < 1 || maze_r > size(maze_grid,1) || maze_c > size(maze_grid,2)
            continue;
        end

        if any(contains(maze_grid{maze_r, maze_c}, "explore"))
            explore_cells(end+1,:) = [r, c];
        end
    end

    if isempty(explore_cells)
        target = [];
        return;
    end

    % 对这些 explore 目标按 A* 路径步数排序
    paths = cell(size(explore_cells,1),1);
    path_lengths = inf(size(explore_cells,1),1);

    for i = 1:size(explore_cells,1)
        goal = explore_cells(i,:);
        path = astar_search(pos, goal, maze_grid, wall_map, elevator_map);
        paths{i} = path;
        if ~isempty(path)
            path_lengths(i) = size(path,1) - 1;
        end
    end

    [~, sort_idx] = sort(path_lengths);
    sorted_cells = explore_cells(sort_idx, :);
    sorted_paths = paths(sort_idx);

    for i = 1:length(sorted_cells)
        path = sorted_paths{i};
        if ~isempty(path)
            target = sorted_cells(i,:);
            return;
        else
            fprintf("🧭 从 (%d,%d) 到 (%d,%d) A* 失败（区域内）\n", ...
                    pos(1), pos(2), sorted_cells(i,1), sorted_cells(i,2));
        end
    end

    target = [];  % 当前区域没有 explore 可达
end
