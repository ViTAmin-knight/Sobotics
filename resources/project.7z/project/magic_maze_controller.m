function magic_maze_controller()
    fprintf("🧠 magic_maze_controller 启动（动态 replanning + 探索）...\n");

    raw_agents = jsondecode(fileread('agent_state.json'));
    agents = struct();

    for i = 1:length(raw_agents)
        agents(i).name = raw_agents(i).name;
        agents(i).pos = [raw_agents(i).row, raw_agents(i).col];
        agents(i).phase = "to_item";
        agents(i).path = [];
        agents(i).step = 2;
        fprintf("📌 %s 起始位置: (%d,%d)\n", agents(i).name, agents(i).pos(1), agents(i).pos(2));
    end

    no_progress_counter = 0;
    max_rounds = 200;

    for round = 1:max_rounds
        fprintf("🔁 回合 %d...\n", round);
        [maze_grid, row_offset, col_offset] = load_maze_grid();
        wall_map = load_wall_map();
        elevator_map = load_elevator_map();
        [item_targets, exit_targets] = find_goal_tiles(maze_grid);

        any_progress = false;

        for i = 1:length(agents)
            a = agents(i);
            if a.phase == "done"
                continue;
            end

            % 获取目标
            if a.phase == "to_item"
                if isKey(item_targets, a.name)
                    goal = item_targets(a.name);
                else
                    goal = find_nearest_explore(a.pos, maze_grid);
                    if isempty(goal)
                        fprintf("⚠️ %s 无 item 且无 explore 可前往\n", a.name);
                        continue;
                    end
                end
            elseif a.phase == "to_exit"
                if isKey(exit_targets, a.name)
                    goal = exit_targets(a.name);
                else
                    goal = find_nearest_explore(a.pos, maze_grid);
                    if isempty(goal)
                        fprintf("⚠️ %s 无 exit 且无 explore 可前往\n", a.name);
                        continue;
                    end
                end
            end

            fprintf("🎯 %s 当前目标: [%d,%d]\n", a.name, goal(1), goal(2));

            % 判断是否需要重新规划
            if isempty(a.path) || a.step > size(a.path,1)
                a.path = astar_search(a.pos, goal, maze_grid, wall_map, elevator_map);
                if isempty(a.path)
                    fprintf("❌ A* 失败：%s -> [%d %d]\n", a.name, goal(1), goal(2));
                    agents(i) = a;
                    continue;
                else
                    fprintf("📐 %s 路径长度: %d, 起点 [%d,%d], 终点 [%d,%d]\n", ...
                        a.name, size(a.path,1), a.path(1,1), a.path(1,2), a.path(end,1), a.path(end,2));
                end

                % 目标就是当前位置
                if size(a.path,1) == 1
                    fprintf("📍 %s 已在目标 [%d,%d] 上\n", a.name, goal(1), goal(2));
                    maze_r = goal(1) - row_offset;
                    maze_c = goal(2) - col_offset;

                    if maze_r >= 1 && maze_c >= 1 && maze_r <= size(maze_grid,1) && maze_c <= size(maze_grid,2)
                        cell_type = maze_grid{maze_r, maze_c};
                        if contains(cell_type, "explore")
                            arm = "arm1"; action = "explore";
                            res = send_action(arm, action, a.name);
                            if strcmp(res.status, "success")
                                fprintf("🧭 %s 控制 %s 执行 explore ✅ 成功\n", arm, a.name);
                                % 强制所有 agent 重规划
                                for j = 1:length(agents)
                                    if j ~= i && agents(j).phase ~= "done"
                                        agents(j).path = [];
                                        agents(j).step = 2;
                                    end
                                end
                            else
                                fprintf("🧭 %s 控制 %s 执行 explore ❌ 失败\n", arm, a.name);
                            end
                            a.path = [];
                            a.step = 2;
                            agents(i) = a;
                            continue;
                        end
                    else
                        fprintf("⚠️ maze_grid 越界访问 (%d,%d)，agent 当前坐标 (%d,%d)\n", ...
                            maze_r, maze_c, a.pos(1), a.pos(2));
                    end

                    if a.phase == "to_item"
                        a.phase = "to_exit";
                    elseif a.phase == "to_exit"
                        a.phase = "done";
                        fprintf("🚪 %s 已逃脱！\n", a.name);
                    end

                    a.path = [];
                    a.step = 2;
                    agents(i) = a;
                    continue;
                end

                a.step = 2;
            end

            % 执行动作
            from = a.path(a.step - 1,:);
            to = a.path(a.step,:);
            d = to - from;

            if isequal(d, [-1 0])
                action = "move_up"; arm = "arm1";
            elseif isequal(d, [1 0])
                action = "move_down"; arm = "arm2";
            elseif isequal(d, [0 -1])
                action = "move_left"; arm = "arm2";
            elseif isequal(d, [0 1])
                action = "move_right"; arm = "arm1";
            else
                fprintf("❌ %s 的方向非法: [%d %d]\n", a.name, d(1), d(2));
                agents(i) = a;
                continue;
            end

            fprintf("▶️ %s 尝试由 %s 执行动作 %s，前往 [%d,%d]\n", a.name, arm, action, to(1), to(2));
            res = send_action(arm, action, a.name);
            if strcmp(res.status, "success")
                a.pos = to;
                a.step = a.step + 1;
                any_progress = true;
                fprintf("🦾 %s 控制 %s 执行 %s ✅ 成功\n", arm, a.name, action);
            else
                fprintf("🦾 %s 控制 %s 执行 %s ❌ 失败\n", arm, a.name, action);
            end

            if a.phase == "to_item" && isKey(item_targets, a.name)
                if isequal(a.pos, item_targets(a.name))
                    fprintf("🎁 %s 已到达 item\n", a.name);
                    a.phase = "to_exit";
                    a.path = [];
                    a.step = 2;
                end
            elseif a.phase == "to_exit" && isKey(exit_targets, a.name)
                if isequal(a.pos, exit_targets(a.name))
                    fprintf("🚪 %s 已逃脱！\n", a.name);
                    a.phase = "done";
                end
            end

            agents(i) = a;
        end

        if all(arrayfun(@(a) a.phase == "done", agents))
            fprintf("🎉 全体棋子已完成游戏目标！胜利！\n");
            return;
        end

        if any_progress
            no_progress_counter = 0;
        else
            no_progress_counter = no_progress_counter + 1;
            fprintf("⏸️ 无进展：连续 %d 回合等待...\n", no_progress_counter);
            if no_progress_counter >= 3
                fprintf("⛔ 连续 3 回合无动作执行，终止。\n");
                return;
            end
        end

        pause(0.4);
    end

    fprintf("🛑 超过最大回合数，未完成游戏目标。\n");
end
