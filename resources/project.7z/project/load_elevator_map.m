function elevator_map = load_elevator_map()
    max_attempts = 5;
    retry_delay = 0.1;  % 秒

    for attempt = 1:max_attempts
        try
            str = fileread('elevator_map.json');
            if isempty(str)
                error("elevator_map.json 是空的。");
            end
            raw = jsondecode(str);  % 如果写到一半会失败
            break;  % ✅ 成功解析，退出 retry 循环
        catch e
            fprintf("⚠️ 第 %d 次读取 elevator_map.json 失败：%s\n", attempt, e.message);
            if attempt == max_attempts
                error("❌ 多次尝试读取 elevator_map.json 失败，终止加载。");
            end
            pause(retry_delay);
        end
    end

    elevator_map = containers.Map();

    for i = 1:length(raw)
        eid = raw(i).id;
        positions = raw(i).positions;
        coords = zeros(length(positions), 2);  % 初始化二维数组

        for j = 1:length(positions)
            row = positions(j).row;  % ✅ MATLAB坐标修正
            col = positions(j).col;
            coords(j, :) = [row, col];
        end

        elevator_map(eid) = coords;
    end

    % ✅ 打印结果
    keys_list = keys(elevator_map);
    %fprintf("✅ elevator_map 加载完成，共 %d 个电梯组：\n", numel(keys_list));
    for i = 1:numel(keys_list)
        eid = keys_list{i};
        coords = elevator_map(eid);
        strs = arrayfun(@(k) sprintf('(%d,%d)', coords(k,1), coords(k,2)), ...
                        1:size(coords,1), 'UniformOutput', false);
        %fprintf("  - ID %s: %s\n", eid, strjoin(strs, ", "));
    end
end
